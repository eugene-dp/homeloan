// Hungarian
fb.data.strings = {
hintClose: "Bez\u00e1r (Esc)",
hintPrev: "El\u0151z\u0151 (\u2190)",
hintNext: "K\u00f6vetkez\u0151 (\u2192)",
hintPlay: "Lej\u00e1tsz\u00e1s (space)",
hintPause: "Meg\u00e1ll\u00edt (space)",
hintResize: "\u00c1tm\u00e9retez (Tab)",
imgCount: "%2 k\u00e9pb\u0151l a(z) %1.",
nonImgCount: "%2 oldalb\u00f3l a(z) %1.",
mixedCount: "(%1 / %2)",
infoText: "Info...",
printText: "Nyomtat...",
flashVer: "Egy \u00fajabb verzi\u00f3j\u00fa 'Flash Player' sz\u00fcks\u00e9ges, a megtekint\u00e9shez e-tartalom.",
needPlayer: "'%1' van sz\u00fcks\u00e9g, hogy ezt a tartalmat.",
open: "Nyit",
view: "Kil\u00e1t\u00e1s a",
newWindow: "Megnyit\u00e1s \u00faj ablakban"
};