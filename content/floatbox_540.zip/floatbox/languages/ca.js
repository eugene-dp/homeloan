// Catalan
fb.data.strings = {
hintClose: "Sortida (teclat: Esc)",
hintPrev: "Enrere (teclat: \u2190)",
hintNext: "Endavant (teclat: \u2192)",
hintPlay: "Activar (teclat: barra espaiadora)",
hintPause: "Pausa (teclat: barra espaiadora)",
hintResize: "Mida (teclat: Tab)",
imgCount: "Imatge %1 de %2",
nonImgCount: "P\u00e0gina %1 de %2",
mixedCount: "(%1 de %2)",
infoText: "Info...",
printText: "Imprimir..",
flashVer: "Es necess\u00e0ria una nova versi\u00f3 de 'Flash Player' per veure aquest contingut.",
needPlayer: "'%1' es necessari para veure aquest contingut.",
open: "Obert",
view: "Veure a",
newWindow: "Obrir en una nova finestra"
};