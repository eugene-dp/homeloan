// German
fb.data.strings = {
hintClose: "Schlie\u00dfen (Taste: Esc)",
hintPrev: "Zur\u00fcck (Taste: \u2190)",
hintNext: "Weiter (Taste: \u2192)",
hintPlay: "Wiedergabe (Taste: Leertaste)",
hintPause: "Anhalten (Taste: Leertaste)",
hintResize: "Skalieren (Taste: Tab)",
imgCount: "Bild %1 von %2",
nonImgCount: "Seite %1 von %2",
mixedCount: "(%1 von %2)",
infoText: "Info...",
printText: "Drucken...",
flashVer: "Zum Anschauen ben\u00f6tigen Sie den Flash-Player in einer neueren Version.",
needPlayer: "Zum Anschauen ben\u00f6tigen Sie den %1.",
open: "\u00d6ffnen",
view: "Ansicht auf",
newWindow: "In neuem Fenster \u00f6ffnen"
};